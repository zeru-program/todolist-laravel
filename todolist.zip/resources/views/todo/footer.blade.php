<footer class="w-100 d-flex flex-column text-center pt-3" style="height:80px; margin-top:100px;padding-bottom:200px;position:relative;bottom:0; background:black;color:white;">
  <h1 class="fw-bold">To-do Laravel</h1>
  <p>
    Created with laravel 11 php 8.3 mysql, by Justine/Zeru
  </p>
</footer>